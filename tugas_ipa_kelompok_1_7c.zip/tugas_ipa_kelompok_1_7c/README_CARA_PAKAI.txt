CARA PAKAI WEBSITE TUGAS IPA KELOMPOK 1 KELAS 7C

1. Extract file ZIP ini.
2. Buka index.html untuk melihat website di browser.
3. Untuk membuat link website online gratis:
   - Buka netlify.com
   - Login / daftar akun
   - Pilih Add new site > Deploy manually
   - Upload folder tugas_ipa_kelompok_1_7c
   - Setelah selesai, Netlify memberi link website.
4. Untuk membuat barcode/QR:
   - Salin link website dari Netlify.
   - Buka website pembuat QR seperti qr-code-generator.com atau qrcode-monkey.com.
   - Tempel link website, lalu download QR.
   - Tempel QR di setiap lembar tugas.

Catatan:
QR belum bisa dibuat final sebelum website punya link online.
